$(function() {



  var siteToggle = $('.navbar-toggler'),
      layer=$('.site__layer'),
      siteMenu= $('.header__right');


  siteToggle.on('click', function(){
    layer.toggleClass('active');
    $(this).toggleClass("collapsed");
      siteMenu.toggleClass("show");
    $('body').toggleClass('overflow-hidden');
  });


  $('.site__layer').on('click', function(){
    layer.removeClass('active');
    siteToggle.removeClass('collapsed');
    siteMenu.removeClass('show');
    $('body').removeClass('overflow-hidden');

  });
  

  $(".toggle-submenu").on('click', function(){
    $(this).parent().toggleClass("open-submenu");
  });




  function equalHeight(elem) {

    var highestBox = 0;
    var heightAuto = 'auto'
    $(elem).height(heightAuto);
    $(elem).each(function(){

      if($(this).height() > highestBox) {
        highestBox = $(this).height(); 
      }
      
    });  
    $(elem).height(highestBox);
  }
  equalHeight('.featured-icons .featured__icon');

  $('.carousel-products').each(function(){
     var title = $(this);
     setTimeout(function() {
      equalHeight(title.find('.product-box__title'));
    }, 500)
  });


  var headerHeight = 0;

  $(window).resize(function() {

      setTimeout(function() {
        headerHeight = $('.header').innerHeight();
      }, 3000) 


       
      
      $('.main-menu').css({'margin-top': $('.header').css('height'), 'height' : 'calc(100% - ' + headerHeight + 'px)'});

   })

  .resize();



  $(".owl-carousel").each(function(){
      $(this).owlCarousel($(this).data())
  });


    $('.tabs .tabs-nav li a').on('click', function (t) { 
    var tabs_parent = $(this).parents('.tabs'), 
      tabs = tabs_parent.find('.tabs-content'), 
      index = $(this).parents('li').index();

      tabs_parent.find('.tabs-nav > .current_tab').removeClass('current_tab');

      $(this).parents('li').addClass('current_tab');
      
      
      tabs.find('.tabs-content-tab').not(':eq(' + index + ')').removeClass('active_tab');
      tabs.find('.tabs-content-tab:eq(' + index + ')').addClass('active_tab');
      t.preventDefault();
    
  } );



  $('.hero-search__input input').on('focus', function() {
    $(this).parent('.hero-search__input').addClass('hero-search_focus');
  }).on('blur', function() {
    $(this).parent('.hero-search__input').removeClass('hero-search_focus');
  })


  $(window).scroll(function () {
     var distanceY = $(this).scrollTop(),
         shrinkOn  = 160,
         header    = $(".header");

    if (distanceY > shrinkOn) {
      header.addClass("smaller");
    } else {
      if (header.hasClass("smaller")) {
        header.removeClass("smaller");
      }
    }
  }); 



// Hide Header on on scroll down
var didScroll;
var lastScrollTop = 0;
var delta = 5;
var navbarHeight = $('header').outerHeight();

$(window).scroll(function(event){
    didScroll = true;
});

setInterval(function() {
    if (didScroll) {
        hasScrolled();
        didScroll = false;
    }
}, 250);

function hasScrolled() {
    var st = $(this).scrollTop();
    
    // Make sure they scroll more than delta
    if(Math.abs(lastScrollTop - st) <= delta)
        return;
    
    // If they scrolled down and are past the navbar, add class .nav-up.
    // This is necessary so you never see what is "behind" the navbar.
    if (st > lastScrollTop && st > navbarHeight){
        // Scroll Down
        $('header').removeClass('nav-down').addClass('nav-up');
    } else {
        // Scroll Up
        if(st + $(window).height() < $(document).height()) {
            $('header').removeClass('nav-up').addClass('nav-down');
        }
    }
    
    lastScrollTop = st;
}



});